package saite.acp.util;

public interface Observer {
    void update();
}
